import firebase from "firebase";
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyBlkL_X4nWqW5Y1TIsDsQZnFOvgyfkKdZM",
  authDomain: "farmacro-af287.firebaseapp.com",
  databaseURL: "https://farmacro-af287.firebaseio.com",
  projectId: "farmacro-af287",
  storageBucket: "farmacro-af287.appspot.com",
  messagingSenderId: "964427814223",
  appId: "1:964427814223:web:8660f5af152ff5299da13a",
  measurementId: "G-78M5EZYR9J",
};

// Initialize Firebase
export default firebase.initializeApp(firebaseConfig);
