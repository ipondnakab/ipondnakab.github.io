export const iconFacebook = "https://www.flaticon.com/svg/static/icons/svg/145/145802.svg"
export const iconGoogle = "https://www.flaticon.com/svg/static/icons/svg/2702/2702602.svg"
export const logoLogin = "https://raw.githubusercontent.com/ipondnakab/Sutima-Kittipat-webapp/master/src/assets/images/img-login-page.svg"
export const logoRegister = "https://raw.githubusercontent.com/ipondnakab/Sutima-Kittipat-webapp/master/src/assets/images/img-register-page.svg"